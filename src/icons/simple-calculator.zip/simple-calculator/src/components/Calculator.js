import { useState,useRef } from "react"

export default function Calculator() {
    const [result,setResult]=useState(0);
    const inRef=useRef(null);
    function add(){
    setResult(result+Number(inRef.current.value));
}
function sub(){
    setResult(result-Number(inRef.current.value));
}
function mul(){
    setResult(result*Number(inRef.current.value));
}
function div(){
    setResult(result/Number(inRef.current.value));
}
function resetResult(){
    setResult(0);
}
function resetInput(){
    inRef.current.value=0;
}
    return<div style={{marginLeft:"20px"}}>    
    <h1>Simplest Calculator</h1>
    <p>{result}</p>
    <input ref={inRef} type="number" min="0" max="9" style={{width:"200px",height:"25px"}} />
    <div className="all-btn" style={{marginTop:"10px"}}>
    <button onClick={add} style={{width:"80px",height:"35px"}}>Addition</button>
    <button onClick={sub} style={{width:"80px",height:"35px"}}>Subtraction</button>
    <button onClick={mul} style={{width:"90px",height:"35px"}}>Multiplication</button>
    <button onClick={div} style={{width:"90px",height:"35px"}}>Division</button>
    <button onClick={resetInput} style={{backgroundColor:"red",width:"100px",height:"30px"}}>Reset Input</button>
    <button onClick={resetResult} style={{backgroundColor:"red",width:"100px",height:"30px"}}>Reset Result</button>

    </div>
    </div>
}